# coding:utf-8
import os
import yaml
import json


def file_path_test(path):
    try:
        f =open(path)
        f.close()
        return True
    except IOError:
        return False


def compare_str(normal_str1, normal_str2):
    lower_str1 = normal_str1.lower()
    lower_str2 = normal_str2.lower()
    if lower_str1 == lower_str2:
        return True
    else:
        return False


def multi_choice(sul, ans):
    if len(ans) > len(sul):
        return 0
    else:
        tmp = []
        for i in range(len(ans)):
            if sul.find(ans[i]) == -1:
                return 0
            else:
                tmp.append(True)
        return sum(tmp)/len(sul)

def multi_blank(sul, ans, score_detail):
    tmp = []
    for key in sul.keys():
        if compare_str(sul[key], ans[key]):
            tmp.append(score_detail[key])
    return float(sum(tmp))

curPath = os.path.dirname(os.path.realpath(__file__))
yamlPath = os.path.join(curPath, "config.yaml")
sulPath = os.path.join(curPath, "solution.json")
ansPath = os.path.join(curPath, "answer.json")

if file_path_test(yamlPath) == False :
    print("Configuration is not found.")
    exit(-1)

if file_path_test(sulPath) == False :
    print("Solution is not found.")
    exit(-1)
    
if file_path_test(ansPath) == False :
    print("Answer is not found.")
    exit(-1)

with open(yamlPath, 'r', encoding='utf-8') as f:
    config = f.read()
configuration = yaml.load(config,Loader=yaml.FullLoader)
problems = configuration['problems']
# print(configuration)

with open(sulPath, 'r', encoding='utf-8') as sul_file:
    sul_data = json.load(sul_file)
# print(sul_data)

with open(ansPath, 'r', encoding='utf-8') as ans_file:
    ans_data = json.load(ans_file)
# print(ans_data)

score_detail = {}
type_detail = {}
for id in range(len(problems)):
    for sub_id in range(len(problems[id]['description'])):
        tmp_d = {problems[id]['description'][sub_id]['name']: problems[id]['description'][sub_id]['score']}
        score_detail.update(tmp_d)
        
        if problems[id]['type'] == 'multiple-choice':
            tmp_d = {problems[id]['description'][sub_id]['name']: 'multiple-choice'}
            type_detail.update(tmp_d)
        elif problems[id]['type'] == 'multiple-blank':
            tmp_d = {problems[id]['name']: 'multiple-blank'}
            type_detail.update(tmp_d)
        else:
            tmp_d = {problems[id]['description'][sub_id]['name']: ''}
            type_detail.update(tmp_d)

score_result = {}
for key in sul_data.keys():
    for sub_key in sul_data[key]:
        if type_detail[sub_key] == 'multiple-blank':
            score = multi_blank(sul_data[key][sub_key],ans_data[key][sub_key],score_detail)
            tmp_d = {sub_key: score}

            score_result.update(tmp_d)
        
        else:
            for subsub_key in sul_data[key][sub_key]:
                if type_detail[subsub_key] == 'multiple-choice':
                    rate = multi_choice(sul_data[key][sub_key][subsub_key],ans_data[key][sub_key][subsub_key])
                    tmp_d = {subsub_key: score_detail[subsub_key]*rate}
                else:
                    if compare_str(sul_data[key][sub_key][subsub_key],ans_data[key][sub_key][subsub_key]):
                        tmp_d = {subsub_key: float(score_detail[subsub_key])}
                    else:
                        tmp_d = {subsub_key: 0.0}
                    
                score_result.update(tmp_d) 

js = json.dumps({"scores": score_result})
print(js)