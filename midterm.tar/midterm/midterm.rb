require "AssessmentBase.rb"

module Midterm
  include AssessmentBase

  def assessmentInitialize(course)
    super("midterm",course)
    @problems = []
  end

end
