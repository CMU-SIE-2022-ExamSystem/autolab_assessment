def multiple_blank(solution, answer):
    return 0.0