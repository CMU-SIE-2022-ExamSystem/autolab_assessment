import os
import sys
import json
# import pytest
# import yaml


def score_assignment(problems):
    return


if __name__ == "__main__":
    print(json.dumps({"scores": {"A": 25, "B": 25, "C": 25, "D": 25}}))
    exit(0)
